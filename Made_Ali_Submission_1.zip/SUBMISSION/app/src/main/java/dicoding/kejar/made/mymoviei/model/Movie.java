package dicoding.kejar.made.mymoviei.model;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {
    String movieName;
    String movieCategory;
    String movieYear;
    String companyProd;
    String actors;
    String movieDesc;
    String movieDuration;
    String movieRating;
    String movieCover;



    public Movie(Parcel in) {

        movieName = in.readString();
        movieCategory = in.readString();
        movieYear = in.readString();
        companyProd = in.readString();
        actors = in.readString();
        movieDesc = in.readString();
        movieDuration = in.readString();
        movieRating = in.readString();
        movieCover = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public Movie() {

    }



    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieCategory() {
        return movieCategory;
    }

    public void setMovieCategory(String movieCategory) {
        this.movieCategory = movieCategory;
    }

    public String getMovieYear() {
        return movieYear;
    }

    public void setMovieYear(String movieYear) {
        this.movieYear = movieYear;
    }





    public String getCompanyProd() {
        return companyProd;
    }

    public void setCompanyProd(String companyProd) {
        this.companyProd = companyProd;
    }

    public String getActors() {
        return actors;
    }

    public void setActors(String actors) {
        this.actors = actors;
    }

    public String getMovieDesc() {
        return movieDesc;
    }

    public void setMovieDesc(String movieDesc) {
        this.movieDesc = movieDesc;
    }

    public String getMovieDuration() {
        return movieDuration;
    }

    public void setMovieDuration(String movieDuration) {
        this.movieDuration = movieDuration;
    }

    public String getMovieRating() {
        return movieRating;
    }

    public void setMovieRating(String movieRating) {
        this.movieRating = movieRating;
    }

    public String getMovieCover() {
        return movieCover;
    }

    public void setMovieCover(String movieCover) {
        this.movieCover = movieCover;
    }









    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {

        parcel.writeString(movieName);
        parcel.writeString(movieCategory);
        parcel.writeString(movieYear);
        parcel.writeString(companyProd);
        parcel.writeString(actors);
        parcel.writeString(movieDesc);
        parcel.writeString(movieDuration);
        parcel.writeString(movieRating);
        parcel.writeString(movieCover);

    }
}
