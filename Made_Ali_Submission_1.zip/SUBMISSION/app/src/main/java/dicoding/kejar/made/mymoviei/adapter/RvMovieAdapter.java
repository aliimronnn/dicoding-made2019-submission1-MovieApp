package dicoding.kejar.made.mymoviei.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import dicoding.kejar.made.mymoviei.R;
import dicoding.kejar.made.mymoviei.activity.DetailMovieActivity;
import dicoding.kejar.made.mymoviei.activity.MainActivity;
import dicoding.kejar.made.mymoviei.model.Movie;

public class RvMovieAdapter extends RecyclerView.Adapter<RvMovieAdapter.CardViewViewHolder> {

    private Context context;
    private ArrayList<Movie> listMovies;
    Movie mov;



    private ArrayList<Movie> getListMovies() {
        return listMovies;
    }

    public void setListMovies(ArrayList<Movie> listMovies) {
        this.listMovies = listMovies;
    }

    public RvMovieAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public CardViewViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_movie, viewGroup, false);
        return  new CardViewViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull CardViewViewHolder cardViewViewHolder, int i) {
        mov = getListMovies().get(i);

        //glide mengambil resources gambar offline / drawable
        Glide.with(context).load(context.getResources().getIdentifier
                (getListMovies().get(i).getMovieCover(), "drawable", context.getPackageName())).into(cardViewViewHolder.imgPhoto);

        cardViewViewHolder.tvMovName.setText(mov.getMovieName());
        cardViewViewHolder.tvMovYear.setText(mov.getMovieYear());
        cardViewViewHolder.tvMovCategory.setText(mov.getMovieCategory());
        cardViewViewHolder.tvMovDuration.setText(mov.getMovieDuration());
        cardViewViewHolder.tvMovRating.setText(mov.getMovieRating());
        cardViewViewHolder.tvMovActors.setText(mov.getActors());

        cardViewViewHolder.imgPhoto.setOnClickListener(new CustomOnItemClickListener(i, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int i) {
                Intent moveWithDataIntent  = new Intent(context, DetailMovieActivity.class);
                moveWithDataIntent.putExtra("MOV", getListMovies().get(i));
                context.startActivity(moveWithDataIntent);

             //   Toast.makeText(context, "Movie Name : "+getListMovies().get(position).getMovieName(), Toast.LENGTH_SHORT).show();
            }
        }));

    }


    @Override
    public int getItemCount() {
        return getListMovies().size();
    }


    public class CardViewViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView tvMovName, tvMovCategory, tvMovRating, tvMovDuration, tvMovYear, tvMovActors;

        public CardViewViewHolder(@NonNull View itemView) {
            super(itemView);

            imgPhoto = itemView.findViewById(R.id.img_item_photo);
            tvMovName = itemView.findViewById(R.id.tv_movie_name);
            tvMovYear = itemView.findViewById(R.id.tv_movie_year);

            tvMovCategory = itemView.findViewById(R.id.tv_movie_category);
            tvMovRating = itemView.findViewById(R.id.tv_movie_rating);
            tvMovDuration = itemView.findViewById(R.id.tv_movie_duration);
            tvMovActors = itemView.findViewById(R.id.tv_movie_actors);

        }
    }
}
