package dicoding.kejar.made.mymoviei.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import org.w3c.dom.Text;

import java.util.ArrayList;

import dicoding.kejar.made.mymoviei.R;
import dicoding.kejar.made.mymoviei.model.Movie;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.CategoryViewHolder>  {

    private Context context;
    private ArrayList<Movie> listmovie;

    public MovieAdapter(Context context) {
        this.context = context;
    }

    public ArrayList<Movie> getListMovie() {
        return listmovie;
    }

    public void setListmovie(ArrayList<Movie> listMovie) {
        this.listmovie = listMovie;
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemRow= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_movie, viewGroup, false);

        return new CategoryViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder categoryViewHolder, int i) {
        categoryViewHolder.tvMovName.setText(getListMovie().get(i).getMovieName());
        categoryViewHolder.tvMovYear.setText(getListMovie().get(i).getMovieYear());
        categoryViewHolder.tvMovCategory.setText(getListMovie().get(i).getMovieCategory());
        categoryViewHolder.tvMovRating.setText(getListMovie().get(i).getMovieRating());
        categoryViewHolder.tvMovDuration.setText(getListMovie().get(i).getMovieDuration());

        Glide.with(context)
                .load(getListMovie().get(i).getMovieCover())
                .apply(new RequestOptions().override(55, 55))
                .into(categoryViewHolder.imgPhoto);



    }

    @Override
    public int getItemCount() {
        return getListMovie().size();
    }

    public class CategoryViewHolder extends RecyclerView.ViewHolder {


            TextView tvMovName;
            TextView tvMovYear;
            TextView tvMovDuration;
            TextView tvMovCategory;
            TextView tvMovRating;
            ImageView imgPhoto;

        public CategoryViewHolder(@NonNull View itemView) {
                super(itemView);
                tvMovName = itemView.findViewById(R.id.tv_movie_name);
                tvMovYear = itemView.findViewById(R.id.tv_movie_year);
                tvMovCategory = itemView.findViewById(R.id.tv_movie_category);
                tvMovRating = itemView.findViewById(R.id.tv_movie_rating);
                tvMovDuration = itemView.findViewById(R.id.tv_movie_duration);
                imgPhoto = itemView.findViewById(R.id.img_item_photo);

            }
        }
    }

