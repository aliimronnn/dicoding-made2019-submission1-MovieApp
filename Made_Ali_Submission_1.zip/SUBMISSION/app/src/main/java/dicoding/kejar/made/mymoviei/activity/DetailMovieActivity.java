package dicoding.kejar.made.mymoviei.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import dicoding.kejar.made.mymoviei.R;
import dicoding.kejar.made.mymoviei.model.Movie;

public class DetailMovieActivity extends AppCompatActivity {
    public static final String MOV ="MOV";

    TextView tv_mov_name, tv_mov_category, tv_mov_year, tv_mov_desc, tv_mov_rating, tv_mov_duration, tv_mov_actors, tv_mov_prod;
    ImageView img_photo;
    Movie mov;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.detail_movie);

        tv_mov_name = findViewById(R.id.tv_movie_name);
        tv_mov_category = findViewById(R.id.tv_movie_category);
        tv_mov_year = findViewById(R.id.tv_movie_year);
        tv_mov_desc = findViewById(R.id.tv_movie_desc);
        tv_mov_rating = findViewById(R.id.tv_movie_rating);
        tv_mov_duration = findViewById(R.id.tv_movie_duration);
        tv_mov_actors = findViewById(R.id.tv_movie_actors);
        tv_mov_prod = findViewById(R.id.tv_movie_production);
        img_photo = findViewById(R.id.img_item_photo);

        mov = getIntent().getParcelableExtra(MOV);

        tv_mov_name.setText(mov.getMovieName());
        tv_mov_category.setText(mov.getMovieCategory());
        tv_mov_year.setText(mov.getMovieYear());
        tv_mov_desc.setText(mov.getMovieDesc());
        tv_mov_rating.setText(mov.getMovieRating());
        tv_mov_duration.setText(mov.getMovieDuration());
        tv_mov_actors.setText(mov.getActors());
        tv_mov_prod.setText(mov.getCompanyProd());
        Glide.with(this)
                .load(this.getResources().getIdentifier
                        (mov.getMovieCover(), "drawable", this.getPackageName())).into(img_photo);

    }




}
