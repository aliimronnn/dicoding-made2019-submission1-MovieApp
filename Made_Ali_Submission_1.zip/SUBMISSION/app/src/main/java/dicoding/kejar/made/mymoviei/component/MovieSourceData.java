package dicoding.kejar.made.mymoviei.component;

import java.util.ArrayList;

import dicoding.kejar.made.mymoviei.model.Movie;

public class MovieSourceData {
    public static String[][] data = new String[][]{
            {"A Star Is Born", "2018", "Musical Romantic Drama", "Bradley Cooper", "136", "8",
                    "Cooper, Lady Gaga, Dave Chappelle, Andrew Dice Clay, and Sam Elliott",
                    "A Star Is Born is a 2018 American musical romantic drama film produced and directed by Bradley Cooper and written by Eric Roth, Cooper and Will Fetters. The third remake of the 1937 film of the same name, it stars Cooper, Lady Gaga, Dave Chappelle, Andrew Dice Clay, and Sam Elliott, and follows a hard-drinking musician (Cooper) who discovers and falls in love with a young singer (Gaga). It marks the third remake of the original 1937 film, after the 1954 musical and the 1976 musical.",
                    "poster_a_star"},
            {"Aqua man", "2018", "Action", "Peter Safran, b Cowan", "143", "9",
                    "Jason Momoa, with Amber Heard, Willem Dafoe, Patrick Wilson, Dolph Lundgren, etc",
                    "Aquaman is a 2018 American superhero film based on the DC Comics character Aquaman and distributed by Warner Bros. Entertainment. It is the sixth installment in the DC Extended Universe (DCEU).",
                    "poster_aquaman"},
            {"Avenger: Infinity War", "2018", "Action", "Kevin Feige", "149", "8.5",
                    " Robert Downey Jr., Chris Hemsworth, Mark Ruffalo, Chris Evans, Scarlett Johansson, etc",
                    "Avengers: Infinity War is a 2018 American superhero film based on the Marvel Comics superhero team the Avengers, produced by Marvel Studios and distributed by Walt Disney Studios Motion Pictures. ",
                    "poster_avengerinfinity"},
            {"Bird Box", "2018", "Horror", "Dylan Clark", "124", "7",
                    "Sandra Bullock, Trevante Rhodes, John Malkovich, Danielle Macdonald, Sarah Paulson",
                    "Bird Box is a 2018 American post-apocalyptic horror thriller film, directed by Susanne Bier from a screenplay written by Eric Heisserer, and based on the 2014 novel of the same name by Josh Malerman. ",
                    "poster_birdbox"},
            {"Bumblebee", "2018", "science fiction action", "Lorenzo di Bonaventura", "114", "7",
                    "Hailee Steinfeld, John Cena, Jorge Lendeborg Jr., John Ortiz, Jason Drucker, and Pamela Adlon",
                    "Bumblebee is a 2018 American science fiction action film centered on the Transformers character of the same name. It is the sixth installment of the live-action Transformers film series,",
                    "poster_bumblebee"},
            {"Creed", "2018", "Sports Drama", "Irwin Winkler", "133", "6",
                    "Michael B. Jordan, Sylvester Stallone, Tessa Thompson, Phylicia Rashad, Anthony Bellew",
                    "Creed is a 2015 American sports drama film directed by Ryan Coogler and written by Coogler and Aaron Covington. Both a spin-off and sequel in the Rocky film series, Michael B. Jordan who played as Adonis Johnson Creed, Apollo Creed's son, with Sylvester Stallone reprising the role of Rocky Balboa.",
                    "poster_creed"},
            {"Bohemian Rhapsody", "2018", "Biographical drama film", "Graham King", "134", "6",
                    "Rami Malek, Lucy Boynton, Gwilym Lee, Ben Hardy, etc",
                    "Bohemian Rhapsody is a 2018 biographical drama film about Freddie Mercury, the lead singer of the British rock band Queen. It follows the singer's life from the formation of the band up to their 1985 Live Aid performance at the original Wembley Stadium. It was directed by Bryan Singer from a screenplay by Anthony McCarten, and produced by Graham King and Queen manager Jim Beach. It stars Rami Malek as Mercury, with Lucy Boynton, Gwilym Lee, Ben Hardy, Joe Mazzello, Aidan Gillen, Tom Hollander, Allen Leech, and Mike Myers in supporting roles. ",
                    "poster_bohemian"},
            {"Deadpool II", "2018", "Action", "Simon Kinberg", "134", "7",
                    "Ryan Reynolds, Josh Brolin,Morena Baccarin,Julian Dennison, Zazie Beetz.",
                    "Deadpool 2 is a 2018 American superhero film based on the Marvel Comics character Deadpool. It is the eleventh installment in the X-Men film series, and is the sequel to 2016's Deadpool. The film was directed by David Leitch from a screenplay by Rhett Reese, Paul Wernick, and Ryan Reynolds, who stars in the title role alongside Josh Brolin, Morena Baccarin, Julian Dennison, Zazie Beetz, T.J. Miller, Brianna Hildebrand, and Jack Kesy. ",
                    "poster_deadpool"},
            {"Hunter Killer", "2018", "Action Thriller", "Neal H. Moritz", "104", "8",
                    "Gerard Butler, Gary Oldman, Michael Nyqvist, Common, Linda Cardellini and Toby Stephens",
                    "Hunter Killer is a 2018 American action thriller film directed by Donovan Marsh, written by Arne Schmidt and Jamie Moss, and based on the 2012 novel Firing Point by Don Keith and George Wallace. The film stars Gerard Butler, Gary Oldman, Michael Nyqvist (in one of his final film roles), Common, Linda Cardellini and Toby Stephens, and follows a submarine crew and a group of Navy SEALs who rescue the captured Russian President from a coup.",
                    "poster_hunterkiller"},
            {"Glass", "2019", "Action", "M. Night Shyamalan", "121", "8",
                    "James McAvoy, Bruce Willis, Anya Taylor-Joy, Sarah Paulson, Samuel L. Jackson",
                    "Glass is a 2019 American psychological superhero thriller film written and directed by M. Night Shyamalan, who also produced with Jason Blum, Marc Bienstock and Ashwin Rajan. The film is a crossover and sequel to Shyamalan's previous films Unbreakable (2000) and Split (2016), serving as the final installment in the Unbreakable trilogy",
                    "poster_glass"},
    };

    public static ArrayList<Movie> getListData() {
        Movie movie = null;
        ArrayList<Movie> list = new ArrayList<>();
        for (String[] aData : data) {
            movie = new Movie();
            movie.setMovieName(aData[0]);
            movie.setMovieYear(aData[1]);
            movie.setMovieCategory(aData[2]);
            movie.setCompanyProd(aData[3]);
            movie.setMovieDuration(aData[4]);
            movie.setMovieRating(aData[5]);
            movie.setActors(aData[6]);
            movie.setMovieDesc(aData[7]);
            movie.setMovieCover(aData[8]);

            list.add(movie);
        }
        return list;
    }
}
